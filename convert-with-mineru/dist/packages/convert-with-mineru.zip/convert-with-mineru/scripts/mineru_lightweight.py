from __future__ import annotations

import time
from pathlib import Path
from typing import Any

import requests

from .mineru_outputs import build_output_targets


def convert_local_file(
    source: Path,
    output_root: Path,
    session: Any | None = None,
    base_url: str = "https://mineru.net/api/v1/agent",
    poll_interval: float = 3.0,
    timeout_seconds: float = 300.0,
) -> Path:
    source = Path(source)
    if session is None:
        session = requests.Session()

    response = session.post(f"{base_url}/parse/file", json={"file_name": source.name})
    response.raise_for_status()
    payload = response.json()
    task_id = payload["data"]["task_id"]
    file_url = payload["data"]["file_url"]

    with source.open("rb") as handle:
        upload = session.put(file_url, data=handle)
        upload.raise_for_status()

    deadline = time.time() + timeout_seconds
    while time.time() <= deadline:
        status = session.get(f"{base_url}/parse/{task_id}")
        status.raise_for_status()
        data = status.json()["data"]
        state = data["state"]
        if state == "done":
            markdown = session.get(data["markdown_url"])
            markdown.raise_for_status()
            targets = build_output_targets(
                source, output_root, include_json=False, keep_raw_tree=False
            )
            targets.markdown.write_text(markdown.text, encoding="utf-8")
            return targets.markdown
        if state == "failed":
            raise RuntimeError(data.get("err_msg") or "lightweight parse failed")
        time.sleep(poll_interval)
    raise TimeoutError(f"timed out waiting for lightweight parse: {source}")
