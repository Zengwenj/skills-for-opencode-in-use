from __future__ import annotations

import argparse
import shutil
from pathlib import Path


EXCLUDED_TOP_LEVEL_NAMES = {
    ".pytest_cache",
    ".venv",
    "HANDOFF-2026-04-01.md",
    "dist",
    "live-repeat-output",
    "live-repeat-sample.html",
    "live-repeat-sample.png",
    "mineru..env",
}
EXCLUDED_ANYWHERE_NAMES = {"__pycache__"}
EXCLUDED_SUFFIXES = {".pyc", ".pyo"}


def should_exclude(path: Path, source_root: Path) -> bool:
    relative_parts = path.relative_to(source_root).parts
    if not relative_parts:
        return False
    if relative_parts[0] in EXCLUDED_TOP_LEVEL_NAMES:
        return True
    return (
        any(part in EXCLUDED_ANYWHERE_NAMES for part in relative_parts)
        or path.suffix in EXCLUDED_SUFFIXES
    )


def build_distribution_tree(source_root: Path, destination: Path) -> Path:
    source_root = source_root.resolve()
    destination = destination.resolve()

    if destination.exists():
        shutil.rmtree(destination)
    destination.mkdir(parents=True, exist_ok=True)

    for path in sorted(source_root.rglob("*")):
        if should_exclude(path, source_root):
            continue
        relative = path.relative_to(source_root)
        target = destination / relative
        if path.is_dir():
            target.mkdir(parents=True, exist_ok=True)
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)

    return destination


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Create a filtered staging copy for skill packaging."
    )
    parser.add_argument(
        "destination", help="Destination directory for the staged skill"
    )
    parser.add_argument(
        "--source-root",
        default=Path(__file__).resolve().parents[1],
        help="Skill root to stage (defaults to this script's parent skill directory)",
    )
    args = parser.parse_args()

    staged = build_distribution_tree(Path(args.source_root), Path(args.destination))
    print(staged)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
