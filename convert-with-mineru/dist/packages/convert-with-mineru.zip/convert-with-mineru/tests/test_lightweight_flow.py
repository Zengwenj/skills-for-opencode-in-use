from pathlib import Path

import scripts.mineru_convert as mineru_convert
from scripts.mineru_config import Settings
from scripts.mineru_lightweight import convert_local_file


class FakeResponse:
    def __init__(self, payload=None, text="", status_code=200):
        self._payload = payload or {}
        self.text = text
        self.status_code = status_code

    def json(self):
        return self._payload

    def raise_for_status(self):
        if self.status_code >= 400:
            raise RuntimeError(f"HTTP {self.status_code}")


class FakeSession:
    def __init__(self):
        self.get_calls = 0

    def post(self, url, json):
        return FakeResponse(
            {
                "code": 0,
                "data": {
                    "task_id": "task-1",
                    "file_url": "https://upload.example/file",
                },
            }
        )

    def put(self, url, data):
        return FakeResponse(status_code=200)

    def get(self, url):
        self.get_calls += 1
        if url.endswith("task-1"):
            if self.get_calls == 1:
                return FakeResponse({"code": 0, "data": {"state": "running"}})
            return FakeResponse(
                {
                    "code": 0,
                    "data": {
                        "state": "done",
                        "markdown_url": "https://download.example/full.md",
                    },
                }
            )
        return FakeResponse(text="# lightweight result")


def test_convert_local_file_writes_source_named_markdown(tmp_path: Path):
    source = tmp_path / "sample.pdf"
    source.write_bytes(b"pdf")

    target = convert_local_file(
        source,
        tmp_path / "out",
        session=FakeSession(),
        poll_interval=0,
        timeout_seconds=1,
    )

    assert target.name == "sample.md"
    assert target.read_text(encoding="utf-8") == "# lightweight result"


def test_main_routes_image_input_to_multimodal_guidance(
    tmp_path: Path, monkeypatch, capsys
):
    source = tmp_path / "scan.png"
    source.write_bytes(b"png")

    monkeypatch.setattr(mineru_convert, "load_settings", lambda config: Settings())
    monkeypatch.setattr("sys.argv", ["mineru_convert", str(source)])

    result = mineru_convert.main()
    captured = capsys.readouterr()

    assert result == 2
    assert "multimodal-looker" in captured.out
    assert str(source) in captured.out


def test_main_processes_mineu_file_and_reports_multimodal_inputs(
    tmp_path: Path, monkeypatch, capsys
):
    pdf = tmp_path / "digital.pdf"
    image = tmp_path / "scan.jpg"
    output = tmp_path / "digital.md"
    pdf.write_bytes(b"%PDF-1.7\nBT /F1 12 Tf (Hello world) Tj ET\n/Font")
    image.write_bytes(b"jpg")

    monkeypatch.setattr(mineru_convert, "load_settings", lambda config: Settings())
    monkeypatch.setattr(
        mineru_convert, "convert_local_file", lambda source, output_root: output
    )
    monkeypatch.setattr("sys.argv", ["mineru_convert", str(pdf), str(image)])

    result = mineru_convert.main()
    captured = capsys.readouterr()

    assert result == 0
    assert str(output) in captured.out
    assert "multimodal-looker" in captured.out
    assert str(image) in captured.out
