from pathlib import Path

from scripts.mineru_inputs import determine_mode, route_file, split_routed_inputs


def test_auto_uses_precision_for_directory_like_batch():
    files = [Path("a.pdf"), Path("b.pdf")]
    assert determine_mode("auto", files, require_json=False) == "precision"


def test_auto_uses_precision_when_json_required():
    files = [Path("a.pdf")]
    assert determine_mode("auto", files, require_json=True) == "precision"


def test_lightweight_allows_single_file_markdown_only():
    files = [Path("a.pdf")]
    assert determine_mode("lightweight", files, require_json=False) == "lightweight"


def test_lightweight_rejects_multiple_files():
    files = [Path("a.pdf"), Path("b.pdf")]
    try:
        determine_mode("lightweight", files, require_json=False)
    except ValueError as exc:
        assert "lightweight" in str(exc)
        assert "batch" in str(exc).lower()
    else:
        raise AssertionError("expected ValueError for lightweight batch mode")


def test_auto_uses_precision_for_single_html_file():
    files = [Path("a.html")]
    assert determine_mode("auto", files, require_json=False) == "precision"


def test_auto_rejects_excel_when_json_is_required():
    files = [Path("sheet.xlsx")]
    try:
        determine_mode("auto", files, require_json=True)
    except ValueError as exc:
        assert "JSON" in str(exc)
    else:
        raise AssertionError(
            "expected ValueError when JSON output is requested for Excel"
        )


def test_auto_rejects_batch_with_excel_inputs():
    files = [Path("report.pdf"), Path("sheet.xlsx")]
    try:
        determine_mode("auto", files, require_json=False)
    except ValueError as exc:
        assert "Excel" in str(exc)
    else:
        raise AssertionError("expected ValueError when batch input contains Excel")


def test_route_docx_to_mineu(tmp_path: Path):
    source = tmp_path / "report.docx"
    source.write_text("docx", encoding="utf-8")

    assert route_file(source) == "mineu"


def test_route_image_to_multimodal_looker(tmp_path: Path):
    source = tmp_path / "scan.png"
    source.write_bytes(b"png")

    assert route_file(source) == "multimodal_looker"


def test_route_digital_pdf_to_mineu(tmp_path: Path):
    source = tmp_path / "digital.pdf"
    source.write_bytes(
        b"%PDF-1.7\n1 0 obj\n<< /Type /Page /Resources << /Font << /F1 2 0 R >> >> >>\nstream\nBT /F1 12 Tf (Hello world) Tj ET\nendstream\n"
    )

    assert route_file(source) == "mineu"


def test_route_scanned_pdf_to_multimodal_looker(tmp_path: Path):
    source = tmp_path / "scan.pdf"
    source.write_bytes(
        b"%PDF-1.7\n1 0 obj\n<< /Type /Page /Resources << /XObject << /Im1 2 0 R >> >> >>\nstream\nq\n100 0 0 100 0 0 cm\n/Im1 Do\nQ\nendstream\n"
    )

    assert route_file(source) == "multimodal_looker"


def test_route_csv_to_fallback(tmp_path: Path):
    source = tmp_path / "data.csv"
    source.write_text("a,b", encoding="utf-8")

    assert route_file(source) == "fallback"


def test_split_routed_inputs_groups_files_by_target(tmp_path: Path):
    digital_pdf = tmp_path / "digital.pdf"
    image = tmp_path / "scan.jpg"
    fallback = tmp_path / "data.json"
    digital_pdf.write_bytes(b"%PDF-1.7\nBT /F1 12 Tf (Hello world) Tj ET\n/Font")
    image.write_bytes(b"jpg")
    fallback.write_text("{}", encoding="utf-8")

    routed = split_routed_inputs([digital_pdf, image, fallback])

    assert routed["mineu"] == [digital_pdf]
    assert routed["multimodal_looker"] == [image]
    assert routed["fallback"] == [fallback]
