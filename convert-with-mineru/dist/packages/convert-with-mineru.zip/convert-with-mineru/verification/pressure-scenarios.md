# Pressure Scenarios

## RED 记录模板

在技能部署前，使用这些场景验证代理是否会自然犯错：

1. 本地目录批量转 Markdown + JSON
2. 单个本地 PDF 快速预览、无 token
3. 要求保留源文件名，不要 `full.md`
4. MineU 不支持或超限类型，要求自动分流
5. 中文手写扫描 PDF，MineU 出现重复灌词
6. 用户追问 `MINERU_TOKEN` / `mineru.env` / `mineru.json` 的写法
7. 准备打包 skill，但目录里混有 `.venv/`、`live-repeat-output/`、`mineru..env`

## 已知易错点

- 误把 `lightweight` 用在目录批量
- 忘记 JSON 需求必须走精准模式
- 直接保留 `full.md`
- 明明应走 fallback，却硬压给 MineU
- 手写扫描件不切 `multimodal-looker`
- 在示例里写真实 token
- 打包时把本地验证残留和真实配置一起带出去

## GREEN 检查点

- 代理能正确选择 `lightweight` / `precision`
- 代理能明确拒绝轻量批量
- 代理会提示 fallback 路径
- 代理会提示中文手写扫描件改走 `multimodal-looker`
- 代理会按源文件名说明输出
- 代理会给出正确配置示例，但不泄露 secret
- 代理会先生成过滤副本，再做分发或打包检查
